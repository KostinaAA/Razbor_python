﻿# -*- coding: utf-8 -*-
import json
import docx 
import os
import nltk
import pymorphy2
from nltk.tokenize import sent_tokenize
from nltk.tokenize import word_tokenize
from nltk.tag import pos_tag
import re



morph = pymorphy2.MorphAnalyzer()

# список искомых частей речи
list_searched_tag = ['PRTF', 'GRND', 'PRTS', 'PRED']

# список шаблонов искомых частей речи в комбинации от 3 и больше частей речи

list_re = [
['PRTF, PRTF', 'PRTF(?:,\s+PRTF){2,}'],
['PRTS, PRTS', 'PRTS(?:,\s+PRTS){2,}'],
['GRND, GRND', 'GRND(?:,\s+GRND){2,}'],
['PRED, PRED', 'PRED(?:,\s+PRED){2,}'],
['и PRTF и PRTF', 'и\s+PRTF\s+(?:и\s+PRTF\s+){2,}'],
['PRTF и PRTF', 'PRTF\s+(?:и\s+PRTF\s+){2,}'],
['PRTF  да PRTF', 'PRTF\s+(?:да\s+PRTF\s+){2,}'],
['PRTF да и PRTF', 'PRTF\s+(?:да\s+и\s+PRTF\s+){2,}'],
['да и PRTF да и PRTF', 'да\s+и\s+PRTF\s+(?:да\s+и\s+PRTF\s+){2,}'],
['PRTF да и PRTF', 'PRTF\s+(?:да\s+и\s+PRTF\s+){2,}'],
['ни PRTF, ни PRTF', 'ни\s+PRTF(?:,\s+ни\s+PRTF){2,}'],
['PRTF, также PRTF', 'PRTF(?:,\s+также\s+PRTF){2,}'],
['PRTF, тоже PRTF', 'PRTF(?:,\s+тоже\s+PRTF){2,}'],
['также и PRTF, также и PRTF', 'также\s+и\s+PRTF(?:,\s+также\s+и\s+PRTF){2,}'],
['PRTF, также и PRTF', 'PRTF(?:,\s+также\s+и\s+PRTF){2,}'],
['PRTF, а PRTF', 'PRTF(?:,\s+а\s+PRTF){2,}'],
['PRTF, но PRTF', 'PRTF(?:,\s+но\s+PRTF){2,}'],
['или PRTF, или PRTF', 'или\s+PRTF(?:,\s+или\s+PRTF){2,}'],
['PRTF или PRTF', 'PRTF\s+(?:или\s+PRTF\s+){2,}'],
['или PRTF, или PRTF', 'или\s+PRTF(?:,\s+или\s+PRTF){2,}'],
['либо PRTF, либо PRTF', 'либо\s+PRTF(?:,\s+либо\s+PRTF){2,}'],
['PRTF либо PRTF', 'PRTF\s+(?:либо\s+PRTF\s+){2,}']]

# определение директории для сканирования файлов
directory = os.curdir 
# формирование списка анализируемых файлов
for docx_file in os.listdir(directory):
    if docx_file.endswith('.docx'):
        doc_text = docx.Document(docx_file)
        # получение имени анализируемого файла
        name_doc_otchet = os.path.splitext(docx_file)[0]
        # создаем объект для формирования выходного файла с результатами
        doc_otchet = docx.Document()
        
        print('Исследуемый файл: ' + docx_file)
        new_file = True
        
        # чтение файла, файл состоит из одной таблицы
        table = doc_text.tables[0]

        # читаем данные из таблицы
        for row in table.rows:
            text = ''
            for cell in row.cells:
                text = cell.text
                text = text.replace('\n', ' ')
                # удаление пробела между цифрами (разделителя тысяч)
                text = re.sub('(?<=\d)[ ](?=\d)', '', text)
                text = text.replace(u'\xa0', ' ')
                
                sent_text = nltk.sent_tokenize(text, language="russian")
                
                # разбиваем предложения на слова
                for n in range(len(sent_text)): 
                    tokens = nltk.word_tokenize(sent_text[n])
                    
                    # формируем список с pos тегами вместо найденных частей речи внутри предложения
                    list_tags = []
                    for i in range(len(tokens)):
                        p = morph.parse(tokens[i])
                        if p[0].tag.POS in list_searched_tag:
                            list_tags.append(p[0].tag.POS)
                        else:
                            list_tags.append(tokens[i])
                            
                    text_string = ' '.join(list_tags)
                    text_string = re.sub(r'\s+(?=(?:[,.?!:;…]))', r'', text_string)

                    # сканируем список шаблонов и проверяем наличие совпадения в списке с pos тегами
                    for j in range(len(list_re)): 
                        regex_num = re.compile(list_re[j][1])  
                        s = regex_num.search(text_string)

                        if s:
                            if new_file:
                                par1 = doc_otchet.add_paragraph('Файл:  ' + docx_file)
                                table = doc_otchet.add_table(rows = 1, cols = 3)
                                table.style = 'Table Grid'
                                hdr_cells = table.rows[0].cells
                                hdr_cells[0].text = 'Предложение:'
                                hdr_cells[1].text = 'Шаблон с более 2 членами речи, в комбинации:'
                                hdr_cells[2].text = 'Структура предложения по искомым частям речи:'
                                row_cells = table.add_row().cells
                                row_cells[0].text = sent_text[n]
                                row_cells[1].text = list_re[j][0] 
                                row_cells[2].text = text_string
                                new_file = False
                            else:
                                row_cells = table.add_row().cells
                                row_cells[0].text = sent_text[n]
                                row_cells[1].text = list_re[j][0] 
                                row_cells[2].text = text_string
        doc_otchet.save('Разбор_файла_' + name_doc_otchet + '_9_2.docx')
        
print('Работа программы завершена')
                            








