﻿# -*- coding: utf-8 -*-
import json
import docx 
import os
import nltk
import pymorphy2
from nltk.tokenize import sent_tokenize
from nltk.tokenize import word_tokenize
from nltk.tag import pos_tag
import re



morph = pymorphy2.MorphAnalyzer()

list_re = [['Если <…>, то <…>./!/?', 'Если(.*?),\s+то\s+(.*?)[.!?]$'],
['Между тем как <…>, <…>./!/?','Между\s+тем\s+как\s+(.*?),(.*?)[.!?]$'],
['<…>, между тем как <…>./!/?','(.*?),\s+между\s+тем\s+как(.*?)[.!?]$'],
['Ровно как <…>, <…>./!/?','Ровно\s+как\s+(.*?),(.*?)[.!?]$'],
['<…>, ровно как <…>./!/?','(.*?),\s+ровно\s+как\s+(.*?)[.!?]$'],
['Так же как <…>, <…>./!/?','Так\s+же\s+как\s+(.*?),(.*?)[.!?]$'],
['<…>, так же как <…>./!/?','(.*?),\s+так\s+же\s+как\s+(.*?)[.!?]$'],
['Поскольку <…>, постольку <…>./!/?','Поскольку\s+(.*?),\s+постольку\s+(.*?)[.!?]$'],
['<…> постольку, постольку <…>./!/?','(.*?)постольку,\s+постольку\s+(.*?)[.!?]$']]

# определение директории для сканирования файлов
directory = os.curdir 
# формирование списка анализируемых файлов
for docx_file in os.listdir(directory):
    if docx_file.endswith('.docx'):
        doc_text = docx.Document(docx_file)
        # получение имени анализируемого файла
        name_doc_otchet = os.path.splitext(docx_file)[0]
        # создаем объект для формирования выходного файла с результатами
        doc_otchet = docx.Document()
        
        print('Исследуемый файл: ' + docx_file)
        new_file = True
        
        # чтение файла, файл состоит из одной таблицы
        table = doc_text.tables[0]

        
        # читаем данные из таблицы
        for row in table.rows:
            text = ''
            for cell in row.cells:
                text = cell.text
                # удаление пробела между цифрами (разделителя тысяч) и пробела перед знаками препинания
                text = re.sub('(?<=\d)[ ](?=\d)', '', text)
                text = text.replace(u'\xa0', ' ')
                text = re.sub(r'\s+(?=(?:[,.?!:;…]))', r'', text)
				# разбиение на предложения
                sents = nltk.sent_tokenize(text, language="russian")

                # сканируем список шаблонов и проверяем наличие совпадения применительно к предложению
                for i in range(len(sents)):
                    for j in range(len(list_re)):
                        regex_num = re.compile(list_re[j][1])
						# если найдено соответствие предложения шаблону
                        if regex_num.search(sents[i]):
							# создаем описание документа и таблицу, если найдено первое совпадение и добавляем строку,
							# иначе добавляем строки в созданную таблицу
							# по оператору break выполнение прекращения цикла проверки на соответствие шаблону
							# при нахождении первого соответствия предложения шаблону нет смысла дальнейшей проверки
                            if new_file:
                                par1 = doc_otchet.add_paragraph('Файл:  ' + docx_file)
                                table = doc_otchet.add_table(rows = 1, cols = 2)
                                table.style = 'Table Grid'
                                hdr_cells = table.rows[0].cells
                                hdr_cells[0].text = 'Предложение:'
                                hdr_cells[1].text = 'Соответствие шаблону:'
                                row_cells = table.add_row().cells
                                row_cells[0].text = sents[i]
                                row_cells[1].text = list_re[j][0] 
                                new_file = False
                            else:
                                row_cells = table.add_row().cells
                                row_cells[0].text = sents[i]
                                row_cells[1].text = list_re[j][0]
                            break
                            

        doc_otchet.save('Разбор_файла_' + name_doc_otchet + '_18.docx')
        
print('Работа программы завершена')
                            








